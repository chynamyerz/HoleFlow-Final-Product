#include "ptoc.h"

void foo()
{
   real t;
   integer page_;

   page_ = sizeof(page_);
   t = atan(get_time());
}

integer time1();


integer time1()
{
   integer time1_result;
   time1_result = maxint;
   return time1_result;
}    /* time */

void atan1()
{
   integer t;

   t = time1();
}