/*
 * $Id: setpalette.c,v 0.1 1993/12/10 00:39:08 king Exp king $
 * Changes one palette colour.
 *
 * $Log: setpalette.c,v $
 * Revision 0.1  1993/12/10  00:39:08  king
 * Initial version.
 *
 */
#include "graphics.h"

void setpalette(int colornum, int color)
{
/*
 * This routine not currently implemented.
 */
}
