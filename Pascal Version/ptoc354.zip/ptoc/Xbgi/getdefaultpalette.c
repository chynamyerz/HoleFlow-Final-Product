/*
 * $Id: getdefaultpalette.c,v 0.1 1993/12/10 00:15:31 king Exp king $
 * Returns the palette definition structure.
 *
 * $Log: getdefaultpalette.c,v $
 * Revision 0.1  1993/12/10  00:15:31  king
 * Initial version.
 *
 */
#include "graphics.h"

struct palettetype *getdefaultpalette(void)
{
/*
 * This routine not currently implmented.
 */
    return NULL;
}
